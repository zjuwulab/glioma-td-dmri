function result = fit_joint_signals(signal, seqParams, opts)
% Fit preprocessed voxel signals using the existing JOINT forward model and sampler.
% signal: Nvox x Nmeasurements. seqParams: Nmeasurements x 7.
% Parameter order: fin, diameter (um), Dex/Din (um^2/ms), kin (s^-1).
% opts.prior_mode: 'nlls', 'fixed20', or 'uniform'.
if nargin<3, opts=struct; end
defaults=struct('prior_mode','nlls','variance_scale',1,'burnin',2000, ...
    'iterations',5000,'n_starts',5,'seed',1025);
names=fieldnames(defaults);
for k=1:numel(names)
    if ~isfield(opts,names{k}),opts.(names{k})=defaults.(names{k});end
end
if isvector(signal),signal=reshape(signal,1,[]);end
assert(size(signal,2)==size(seqParams,1) && size(seqParams,2)==7);
assert(all(isfinite(signal(:))) && all(signal(:)>0));
rng(opts.seed,'twister');
bounds=[0,0,.1,.1,1;1,40,3,3,100];
starts={linspace(.1,.9,100),linspace(1,30,100),linspace(.5,3,100), ...
    linspace(.5,3,100),linspace(1,100,100)};
nv=size(signal,1);nlls=zeros(nv,5);means=zeros(nv,5);rmse=zeros(nv,1);
optimizer=optimset('Display','off');
for v=1:nv
    y=double(signal(v,:));best=Inf;initial=[];
    for restart=1:opts.n_starts
        x0=zeros(1,5);
        for p=1:5,x0(p)=starts{p}(randi(100));end
        [x,~,residual]=lsqcurvefit(@JOINT_3,x0,seqParams,y',bounds(1,:),bounds(2,:),optimizer);
        err=mean(residual.^2);
        if isfinite(err) && err<best,best=err;initial=x(:)';end
    end
    assert(~isempty(initial),'No finite NLLS solution at voxel %d.',v);
    nlls(v,:)=initial;E=initial;
    prior={'flat','Lognorm','flat','flat','Lognorm'};
    switch lower(opts.prior_mode)
        case 'nlls'
            if initial(2)<3 || initial(2)>35,prior{2}='reci';end
            if initial(5)<3 || initial(5)>80,prior{5}='reci';end
        case 'fixed20'
            E([2,5])=20;
        case 'uniform'
            prior={'flat','flat','flat','flat','flat'};
        otherwise,error('Unknown prior_mode: %s',opts.prior_mode);
    end
    variance=[0,80,0,0,100]*opts.variance_scale;
    posterior=Bayes_Joint(y,initial(1),initial(2),initial(3),initial(4),initial(5), ...
        seqParams,bounds,opts.iterations,prior,opts.burnin,E,variance);
    means(v,:)=[posterior.f.mean,posterior.diameter.mean,posterior.Dex.mean,posterior.Din.mean,posterior.kin.mean];
    predicted=JOINT_3(means(v,:),seqParams);
    rmse(v)=sqrt(mean((predicted(:)-y(:)).^2));
end
result=derive_joint_parameters(means);
result.nlls=nlls;result.parameters=means;result.rmse=rmse;
result.options=opts;result.seqParams=seqParams;
end
