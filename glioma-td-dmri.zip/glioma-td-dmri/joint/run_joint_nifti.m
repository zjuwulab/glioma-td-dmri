function result = run_joint_nifti(cfg)
% cfg: files (14 paths), b0_files (4 paths), mask_file, roi_value, output_dir,
%      seqParams (14x7), options (fit_joint_signals options).
% Requires load_untouch_nii and save_untouch_nii on the MATLAB path.
if ~isfield(cfg,'roi_value'),cfg.roi_value=2;end
if ~isfield(cfg,'options'),cfg.options=struct;end
groups=[1,1,2,2,2,2,3,3,3,3,4,4,4,4];
assert(numel(cfg.files)==14 && numel(cfg.b0_files)==4);
template=load_untouch_nii(cfg.mask_file);shape=size(template.img);
indices=find(template.img==cfg.roi_value);assert(~isempty(indices),'Empty ROI.');
S=zeros(numel(indices),14);S0=S;
for k=1:14
    volume=load_untouch_nii(cfg.files{k});assert(isequal(size(volume.img),shape));
    S(:,k)=double(volume.img(indices));
end
for k=1:4
    volume=load_untouch_nii(cfg.b0_files{k});assert(isequal(size(volume.img),shape));
    S0(:,groups==k)=repmat(double(volume.img(indices)),1,sum(groups==k));
end
valid=all(isfinite(S)&isfinite(S0)&S>0&S0>=0,2);
indices=indices(valid);assert(~isempty(indices),'No valid positive-signal voxels.');
signal=prepare_joint_signal(S(valid,:),S0(valid,:),cfg.seqParams,groups);
result=fit_joint_signals(signal,cfg.seqParams,cfg.options);
if ~exist(cfg.output_dir,'dir'),mkdir(cfg.output_dir);end
names={'fin','diameter','Dex','Din','kin','tau_in','tau_ex','Cellularity'};
template.hdr.dime.datatype=16;template.hdr.dime.bitpix=32;
for k=1:numel(names)
    map=zeros(shape,'single');map(indices)=single(result.(names{k}));
    template.img=map;
    save_untouch_nii(template,fullfile(cfg.output_dir,[names{k},'_mean.nii']));
end
map=zeros(shape,'single');map(indices)=single(result.rmse);template.img=map;
save_untouch_nii(template,fullfile(cfg.output_dir,'fit_rmse.nii'));
save(fullfile(cfg.output_dir,'fit_summary.mat'),'result','indices','cfg');
end
