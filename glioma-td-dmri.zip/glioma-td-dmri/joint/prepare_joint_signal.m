function corrected = prepare_joint_signal(S,S0,seqParams,groups)
% Normalize by measured b0+1, then by the monoexponential nonzero-b intercept.
% S, S0: Nvox x Nmeasurements; groups labels diffusion-time acquisition blocks.
signal=double(S)./(double(S0)+1);
assert(all(isfinite(signal(:))) && all(signal(:)>0));
corrected=signal;b=seqParams(:,5);
for v=1:size(signal,1)
    for g=unique(groups(:))'
        ind=(groups(:)==g)&b>190e6&b<1050e6;
        if sum(ind)>=2
            p=polyfit(b(ind)',-log(signal(v,ind)),1);
            corrected(v,ind)=signal(v,ind)/exp(-polyval(p,0));
        end
    end
end
end
