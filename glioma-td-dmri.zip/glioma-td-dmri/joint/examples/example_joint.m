% Synthetic single-voxel fitting demonstration.
setup_joint;
seqParams=study_sequence;
truth=[.3,15,1.5,1,20];
signal=JOINT_3(truth,seqParams)';
opts=struct('prior_mode','nlls','seed',1025,'burnin',2000,'iterations',5000);
result=fit_joint_signals(signal,seqParams,opts);
disp(result.parameters);
