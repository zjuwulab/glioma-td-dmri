function cfg = example_config(data_dir,mask_file,output_dir)
% Paths for the 14 unregistered NIfTI measurements; adapt filenames if registered.
names={'og50_b250.nii','og50_b500.nii', ...
    'og25_b250.nii','og25_b500.nii','og25_b750.nii','og25_b1000.nii', ...
    'pg30_b250.nii','pg30_b500.nii','pg30_b750.nii','pg30_b1000.nii', ...
    'pg50_b250.nii','pg50_b500.nii','pg50_b750.nii','pg50_b1000.nii'};
b0={'og50_b0.nii','og25_b0.nii','pg30_b0.nii','pg50_b0.nii'};
cfg.files=cellfun(@(n)fullfile(data_dir,n),names,'UniformOutput',false);
cfg.b0_files=cellfun(@(n)fullfile(data_dir,n),b0,'UniformOutput',false);
cfg.mask_file=mask_file;cfg.roi_value=2;cfg.output_dir=output_dir;
cfg.seqParams=study_sequence;
cfg.options=struct('prior_mode','nlls','seed',1025);
end
