function out = derive_joint_parameters(parameters)
% Derive additional parameters from posterior means of the fitted parameters.
% Columns: fin, diameter (um), Dex/Din (um^2/ms), kin (s^-1).
out.fin=parameters(:,1);out.diameter=parameters(:,2);
out.Dex=parameters(:,3);out.Din=parameters(:,4);out.kin=parameters(:,5);
out.tau_in=1000./out.kin;                  % ms
out.tau_ex=(1-out.fin).*out.tau_in;        % overall exchange time, ms
out.Cellularity=100*out.fin./out.diameter; % apparent index, um^-1
end
