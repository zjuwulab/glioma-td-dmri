function setup_joint
% Add the fitting interfaces, model functions and examples to the MATLAB path.
root=fileparts(mfilename('fullpath'));
addpath(fullfile(root,'joint'));
addpath(fullfile(root,'joint','core'));
addpath(fullfile(root,'joint','sequence_helpers'));
addpath(fullfile(root,'joint','examples'));
end
