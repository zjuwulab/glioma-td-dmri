# Histology quantification

Python implementation of the manuscript's calculation formulas.

## Input

| Option | CSV columns |
| --- | --- |
| `--regions` | `sample_id,nuclear_area,tissue_area` |
| `--fractions` | `sample_id,nuclear_area_fraction` |
| `--nuclei` (optional) | `sample_id,nuclear_area`, one row per nucleus |

Use matching area units and fractions on the 0–1 scale. `sample_id` groups non-overlapping regions for each sample. Supply the measured area of the selected tissue region as `tissue_area`.

## Calculation

```text
a = sum(nuclear_area) / sum(tissue_area)
q = a^(3/2)
d_i = 2*sqrt(A_i/pi)
d_weighted = sum(d_i^4) / sum(d_i^3)
```

## Run

From the repository directory:

```sh
python histology/postprocess.py --regions histology/examples/regions.csv --output results/histology.csv
python histology/postprocess.py --fractions histology/examples/fractions.csv --output results/transformed.csv
```

For nuclear diameters, add `--nuclei FILE --area-unit um2`. With pixel areas, use `--area-unit px2 --pixel-size-um VALUE` to supply the calibrated pixel size. Diameters are returned in µm.

The supplied CSV files contain synthetic examples.
