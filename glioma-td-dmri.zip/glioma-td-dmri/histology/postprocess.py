#!/usr/bin/env python3
"""Formula-based histology quantification; Python standard library only.

Computes nuclear area fractions, the a**(3/2) transformation and weighted
nuclear diameters from CSV inputs. See README.md for input definitions.
"""
import argparse
import csv
import math
from pathlib import Path


def number(value, label, *, positive=False):
    """Read a finite, nonnegative measurement (strictly positive if requested)."""
    value = float(value)
    if not math.isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError(f"{label} must be finite and {'positive' if positive else 'nonnegative'}")
    return value


def transform_fraction(area_fraction):
    """Apply the study's specified a**(3/2) transformation to a fraction, not %."""
    a = number(area_fraction, 'nuclear_area_fraction')
    if a > 1:
        raise ValueError('nuclear_area_fraction must be in [0,1], not percent')
    return a ** 1.5


def pooled_area_fraction(nuclear_areas, tissue_areas):
    """Compute sum(nuclear area)/sum(tissue area) over disjoint selected regions."""
    nuclei = [number(x, 'nuclear_area') for x in nuclear_areas]
    tissue = [number(x, 'tissue_area', positive=True) for x in tissue_areas]
    if not nuclei or len(nuclei) != len(tissue):
        raise ValueError('Provide equally sized, nonempty nuclear/tissue area lists')
    if any(n > t for n, t in zip(nuclei, tissue)):
        raise ValueError('Nuclear area exceeds the corresponding tissue area')
    return math.fsum(nuclei) / math.fsum(tissue)


def nuclear_diameters(nuclear_areas, *, area_unit, pixel_size_um=None):
    """Equivalent-circle diameters and the specified fourth/third-moment mean.

    Input areas refer to individual segmented nuclei. Pixel areas are converted
    using the supplied isotropic pixel size; diameters are returned in micrometres.
    """
    if area_unit == 'um2':
        if pixel_size_um is not None:
            raise ValueError('pixel_size_um is only used with area_unit=px2')
        area_scale = 1.0
    elif area_unit == 'px2':
        if pixel_size_um is None:
            raise ValueError('Pixel areas require pixel_size_um')
        area_scale = number(pixel_size_um, 'pixel_size_um', positive=True) ** 2
    else:
        raise ValueError('Nuclear diameter requires area_unit=um2 or px2')
    diameters = [2 * math.sqrt(number(a, 'individual nuclear area', positive=True)
                              * area_scale / math.pi) for a in nuclear_areas]
    if not diameters:
        raise ValueError('No individual nuclei supplied for diameter calculation')
    weighted = math.fsum(d ** 4 for d in diameters) / math.fsum(d ** 3 for d in diameters)
    return diameters, weighted


def read_csv(path, required):
    with Path(path).open(newline='', encoding='utf-8-sig') as stream:
        reader = csv.DictReader(stream)
        if not set(required).issubset(reader.fieldnames or []):
            raise ValueError('Missing CSV columns: ' + ', '.join(sorted(set(required) - set(reader.fieldnames or []))))
        rows = list(reader)
    if not rows:
        raise ValueError('Input CSV has no data rows')
    for row in rows:
        row['sample_id'] = row['sample_id'].strip()
        if not row['sample_id']:
            raise ValueError('sample_id cannot be empty')
    return rows


def quantify(*, regions=None, fractions=None, nuclei=None, area_unit='common', pixel_size_um=None):
    """Produce sample-level metrics from either regional areas or final fractions."""
    if (regions is None) == (fractions is None):
        raise ValueError('Supply exactly one of regions or fractions')
    results = {}
    if regions is not None:
        grouped = {}
        for row in regions:
            grouped.setdefault(row['sample_id'], []).append(row)
        for sample_id, rows in grouped.items():
            nuclear = [number(row['nuclear_area'], 'nuclear_area') for row in rows]
            tissue = [number(row['tissue_area'], 'tissue_area', positive=True) for row in rows]
            a = pooled_area_fraction(nuclear, tissue)
            results[sample_id] = dict(sample_id=sample_id, n_regions=len(rows),
                total_nuclear_area=math.fsum(nuclear), total_tissue_area=math.fsum(tissue),
                area_unit=area_unit, nuclear_area_fraction=a,
                nuclear_fraction_3over2=transform_fraction(a))
    else:
        for row in fractions:
            sample_id = row['sample_id']
            if sample_id in results:
                raise ValueError('Duplicate sample_id in final fractions input: ' + sample_id)
            a = number(row['nuclear_area_fraction'], 'nuclear_area_fraction')
            results[sample_id] = dict(sample_id=sample_id, nuclear_area_fraction=a,
                                     nuclear_fraction_3over2=transform_fraction(a))
    if nuclei is not None:
        grouped = {}
        for row in nuclei:
            sample_id = row['sample_id']
            if sample_id not in results:
                raise ValueError('Nucleus sample_id absent from primary input: ' + sample_id)
            grouped.setdefault(sample_id, []).append(row['nuclear_area'])
        for sample_id, areas in grouped.items():
            diameters, weighted = nuclear_diameters(areas, area_unit=area_unit,
                                                   pixel_size_um=pixel_size_um)
            results[sample_id].update(n_nuclei=len(diameters),
                weighted_nuclear_diameter_um=weighted)
    return list(results.values())


FIELDS = ['sample_id', 'n_regions', 'total_nuclear_area', 'total_tissue_area',
          'area_unit', 'nuclear_area_fraction', 'nuclear_fraction_3over2',
          'n_nuclei', 'weighted_nuclear_diameter_um']


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--regions', type=Path, help='CSV: sample_id,nuclear_area,tissue_area')
    source.add_argument('--fractions', type=Path, help='CSV: sample_id,nuclear_area_fraction')
    parser.add_argument('--nuclei', type=Path, help='Optional per-nucleus CSV: sample_id,nuclear_area')
    parser.add_argument('--area-unit', choices=['common', 'um2', 'px2'], default='common')
    parser.add_argument('--pixel-size-um', type=float, help='Required for diameters from pixel areas')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        output = quantify(
            regions=read_csv(args.regions, ['sample_id','nuclear_area','tissue_area']) if args.regions else None,
            fractions=read_csv(args.fractions, ['sample_id','nuclear_area_fraction']) if args.fractions else None,
            nuclei=read_csv(args.nuclei, ['sample_id','nuclear_area']) if args.nuclei else None,
            area_unit=args.area_unit, pixel_size_um=args.pixel_size_um)
    except ValueError as error:
        parser.error(str(error))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(output)
    print(f'Wrote {len(output)} samples to {args.output}')


if __name__ == '__main__':
    main()
