"""Independent hand-calculated controls for the scientific transformations."""
import csv
import importlib.util
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / 'postprocess.py'
spec = importlib.util.spec_from_file_location('postprocess', MODULE)
post = importlib.util.module_from_spec(spec)
spec.loader.exec_module(post)


class HistologyChecks(unittest.TestCase):
    def test_pool_before_division(self):
        # Unequal tissue areas: 100/400=.25, whereas mean(.1,.3)=.2.
        a = post.pooled_area_fraction([10,90], [100,300])
        self.assertEqual(a, .25)
        self.assertEqual(post.transform_fraction(a), .125)

    def test_transform_without_changing_final_input(self):
        output = post.quantify(fractions=[dict(sample_id='synthetic', nuclear_area_fraction=.64)])
        self.assertEqual(output[0]['nuclear_area_fraction'], .64)
        self.assertAlmostEqual(output[0]['nuclear_fraction_3over2'], .512)

    def test_fraction_boundaries_and_invalid_units(self):
        self.assertEqual(post.transform_fraction(0), 0)
        self.assertEqual(post.transform_fraction(1), 1)
        for value in [-.1, 25, float('nan'), float('inf')]:
            with self.assertRaises(ValueError): post.transform_fraction(value)
        with self.assertRaises(ValueError): post.pooled_area_fraction([2], [1])
        with self.assertRaises(ValueError): post.pooled_area_fraction([0], [0])

    def test_nuclear_diameter_and_calibration(self):
        # Areas pi and 4*pi correspond to diameters 2 and 4 micrometres.
        ds, weighted = post.nuclear_diameters([math.pi,4*math.pi], area_unit='um2')
        self.assertEqual(ds, [2,4])
        self.assertAlmostEqual(weighted, 34/9)
        _, half_scale = post.nuclear_diameters([math.pi,4*math.pi], area_unit='px2', pixel_size_um=.5)
        self.assertAlmostEqual(half_scale, 17/9)
        with self.assertRaises(ValueError): post.nuclear_diameters([1], area_unit='px2')

    def test_cli_synthetic_roundtrip(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory)/'metrics.csv'
            example = MODULE.parent/'examples/regions.csv'
            subprocess.run([sys.executable,str(MODULE),'--regions',str(example),
                            '--output',str(target)], check=True, capture_output=True)
            with target.open(newline='') as stream: rows=list(csv.DictReader(stream))
            self.assertEqual(len(rows),2)
            self.assertEqual(rows[0]['sample_id'],'synthetic_A')
            self.assertEqual(float(rows[0]['nuclear_fraction_3over2']),.125)
            self.assertAlmostEqual(float(rows[1]['nuclear_fraction_3over2']),.512)


if __name__ == '__main__':
    unittest.main()
